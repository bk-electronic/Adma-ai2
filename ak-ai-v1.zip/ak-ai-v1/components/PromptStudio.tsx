"use client";

import { useState } from "react";
import {
  ArrowRight, Sparkles, Copy, Check, Wand2, RefreshCw, ChevronDown,
  Film, Camera, Lightbulb, UserRound, MapPin, Move3D, ShieldCheck,
  Ban, Clapperboard, MessageSquare
} from "lucide-react";

const models = ["Auto", "Veo", "Kling", "Runway", "Sora", "Generic"];

const sample = "एक आदमी बारिश में रात के समय सुनसान सड़क पर अकेला चल रहा है। कैमरा उसके सामने से धीरे-धीरे पीछे की ओर move करे, चेहरे पर हल्की उदासी हो और पूरी scene cinematic लगे।";

const sections = [
  ["Character", "एक अकेला वयस्क पुरुष, चेहरे पर शांत लेकिन हल्की उदासी।", UserRound],
  ["Environment", "रात की सुनसान, गीली शहरी सड़क; बारिश के बाद चमकती asphalt surface।", MapPin],
  ["Action", "वह धीरे-धीरे कैमरे की ओर चलते हुए आगे बढ़ता है।", Clapperboard],
  ["Camera", "Eye-level frontal tracking shot, camera subject के सामने रहकर धीरे-धीरे पीछे move करे।", Camera],
  ["Lighting", "Soft cool street lights, wet-surface reflections, subtle cinematic contrast।", Lightbulb],
  ["Visual Style", "Photorealistic cinematic drama, natural skin texture, premium film look।", Film],
  ["Motion", "हल्की बारिश, कपड़ों और बालों में natural movement, controlled walking pace।", Move3D],
  ["Consistency", "चेहरा, hairstyle, clothing और body appearance पूरे shot में consistent रहें।", ShieldCheck],
  ["Restrictions", "No camera flip to rear view, no sudden cuts, no distorted anatomy, no extra people।", Ban],
];

export default function PromptStudio() {
  const [model, setModel] = useState("Auto");
  const [idea, setIdea] = useState("");
  const [generated, setGenerated] = useState(false);
  const [copied, setCopied] = useState(false);
  const [improveOpen, setImproveOpen] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [version, setVersion] = useState(1);

  const generate = () => {
    if (!idea.trim()) setIdea(sample);
    setGenerated(true);
    setVersion(1);
    window.setTimeout(() => document.getElementById("result")?.scrollIntoView({ behavior: "smooth" }), 80);
  };

  const copyPrompt = async () => {
    const text = `${idea || sample}\n\nCreate a production-ready cinematic video prompt with consistent character, environment, action, frontal tracking camera, realistic motion, lighting and negative constraints.`;
    await navigator.clipboard?.writeText(text);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };

  const improve = () => {
    setVersion(2);
    setImproveOpen(false);
    document.getElementById("result")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <main>
      <header className="topbar">
        <div className="brand"><span className="brandMark">AK</span><span>AK AI</span></div>
        <nav>
          <a href="#studio">Prompt Studio</a>
          <a href="#how">How it works</a>
          <button className="ghostBtn">Sign in</button>
        </nav>
      </header>

      <section className="hero" id="studio">
        <div className="heroGlow" />
        <div className="eyebrow"><Sparkles size={15}/> VIDEO PROMPT INTELLIGENCE</div>
        <h1>Turn your imagination into<br/><span>production-ready video prompts.</span></h1>
        <p>Describe your idea naturally. AK AI understands the intent, finds missing details and builds a prompt designed for your video model.</p>

        <div className="studioCard">
          <div className="cardTop">
            <div>
              <div className="label">YOUR IDEA</div>
              <h2>आप क्या बनाना चाहते हैं?</h2>
            </div>
            <div className="secure"><ShieldCheck size={15}/> Intent-first</div>
          </div>

          <textarea
            value={idea}
            onChange={(e) => setIdea(e.target.value)}
            placeholder="उदाहरण: एक आदमी बारिश में रात के समय सुनसान सड़क पर अकेला चल रहा है..."
          />

          <div className="controls">
            <div className="modelBox">
              <span>Video Model</span>
              <select value={model} onChange={(e) => setModel(e.target.value)}>
                {models.map((m) => <option key={m}>{m}</option>)}
              </select>
            </div>
            <button className="generate" onClick={generate}>
              <Wand2 size={18}/> Generate Perfect Prompt <ArrowRight size={18}/>
            </button>
          </div>
          <div className="hint">AK AI will preserve your idea and only add details that improve video generation.</div>
        </div>
      </section>

      <section className="process" id="how">
        <div className="processItem"><span>01</span><b>Understand</b><small>आपकी सोच</small></div>
        <div className="line"/>
        <div className="processItem"><span>02</span><b>Complete</b><small>Missing details</small></div>
        <div className="line"/>
        <div className="processItem"><span>03</span><b>Optimize</b><small>Model-ready prompt</small></div>
        <div className="line"/>
        <div className="processItem"><span>04</span><b>Improve</b><small>Closer to your vision</small></div>
      </section>

      {generated && (
        <section className="resultSection" id="result">
          <div className="sectionHeading">
            <div><div className="label">ANALYSIS • VERSION {version}</div><h2>We understood your vision.</h2></div>
            <button className="secondary" onClick={() => setGenerated(false)}><RefreshCw size={16}/> New Prompt</button>
          </div>

          <div className="grid">
            {sections.map(([title, desc, Icon]) => (
              <div className="detailCard" key={String(title)}>
                <div className="icon"><Icon size={18}/></div>
                <div><h3>{title}</h3><p>{desc}</p></div>
              </div>
            ))}
          </div>

          <div className="finalCard">
            <div className="finalHeader">
              <div><div className="label">FINAL OPTIMIZED PROMPT</div><h2>{model === "Auto" ? "Auto-optimized" : model} production prompt</h2></div>
              <span className="versionBadge">V{version}</span>
            </div>
            <div className="promptText">
              {idea || sample} Create a photorealistic cinematic sequence. Preserve the subject&apos;s identity, clothing and proportions throughout. Use a frontal eye-level tracking camera that slowly moves backward while the subject walks forward. Maintain natural rain, realistic reflections, subtle emotional performance, controlled motion and consistent lighting. No rear camera angle, no sudden cuts, no extra people, no distorted anatomy, no identity drift.
            </div>
            <div className="actions">
              <button className="primary" onClick={copyPrompt}>{copied ? <Check size={17}/> : <Copy size={17}/>} {copied ? "Copied" : "Copy Prompt"}</button>
              <button className="secondary" onClick={() => setImproveOpen(true)}><MessageSquare size={17}/> मेरी सोच के और करीब बनाओ</button>
              <button className="secondary" onClick={generate}><RefreshCw size={17}/> Regenerate</button>
            </div>
          </div>
        </section>
      )}

      <footer><div className="brand"><span className="brandMark">AK</span><span>AK AI</span></div><span>Prompt Intelligence for creators.</span></footer>

      {improveOpen && (
        <div className="modalBackdrop" onClick={() => setImproveOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modalIcon"><Wand2 size={20}/></div>
            <h2>मेरी सोच के और करीब बनाओ</h2>
            <p>Output आपकी सोच से कहाँ अलग था? AK AI सिर्फ चुने हुए हिस्से को बदलेगा और बाकी prompt को preserve करेगा।</p>
            <div className="checks">
              {["Character","Face","Clothing","Background","Camera","Movement","Emotion","Lighting","Action"].map((x) => (
                <button key={x} className={selected.includes(x) ? "check active" : "check"} onClick={() => setSelected(s => s.includes(x) ? s.filter(i => i !== x) : [...s, x])}>{selected.includes(x) ? "✓" : "○"} {x}</button>
              ))}
            </div>
            <textarea value={feedback} onChange={(e) => setFeedback(e.target.value)} placeholder='उदाहरण: "मैं चाहता था camera आदमी के सामने से आए, पीछे से नहीं।"'/>
            <div className="modalActions"><button className="secondary" onClick={() => setImproveOpen(false)}>Cancel</button><button className="primary" onClick={improve}>Improve to V2 <ArrowRight size={17}/></button></div>
          </div>
        </div>
      )}
    </main>
  );
}

# AK AI V1

Mobile-friendly Next.js starter for the AK AI Video Prompt Intelligence product.

## V1 scope
- Natural-language video idea input
- Video model selection
- Structured prompt analysis
- Final optimized prompt
- Copy prompt
- Targeted "मेरी सोच के और करीब बनाओ" feedback
- Version 2 UI flow

## Important
This is the frontend/product shell. The real AI Prompt Engine should be connected through a server-side API route / AI Gateway so provider API keys are never exposed in the browser.

Recommended next backend layers:
1. `/api/prompt` — generate
2. `/api/improve` — targeted improvement
3. AI Gateway
4. Model Router
5. Provider adapters for OpenAI / Claude / Gemini
6. Usage + credit controls

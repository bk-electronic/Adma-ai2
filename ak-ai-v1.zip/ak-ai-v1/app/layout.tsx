import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AK AI — Video Prompt Intelligence",
  description: "Turn your imagination into production-ready video prompts.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}